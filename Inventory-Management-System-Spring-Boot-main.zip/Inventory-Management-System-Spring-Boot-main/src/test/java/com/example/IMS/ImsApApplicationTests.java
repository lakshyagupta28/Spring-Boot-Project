package com.example.IMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImsApApplicationTests {

	@Test
	void contextLoads() {
	}

}
